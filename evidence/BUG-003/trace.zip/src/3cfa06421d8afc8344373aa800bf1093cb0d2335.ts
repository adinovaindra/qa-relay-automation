import { test, expect, type Locator } from "@playwright/test";
import { deleteTestConversationBetweenUsers, deleteTestUserByEmail, disconnectCleanupDatabase } from "../support/database-cleanup";
import { createTestConversationBetweenUsers, createTestMessageInConversation, upsertRegisteredUser, disconnectSetupDatabase } from "../support/database-setup";

const alice = {
  name: "Alice",
  email: "alice@example.com",
  password: "password123",
};

const bob = {
  name: "Bob",
  email: "bob@example.com",
  password: "password123",
};

const charlie = {
  name: "Charlie",
  email: "charlie@example.com",
  password: "password123",
};

const bobMessage = "Hi Bob. How are you?";
const charlieMessage = "Hi Charlie. How are you?";

async function expectWithinBounds(element: Locator, container: Locator): Promise<void> {
  const elementBox = await element.boundingBox();
  const containerBox = await container.boundingBox();

  expect(elementBox, "Element should have a measurable bounding box").not.toBeNull();
  expect(containerBox, "Container should have a measurable bounding box").not.toBeNull();

  if (!elementBox || !containerBox) {
    throw new Error("Unable to measure element or container bounds.");
  }

  expect.soft(elementBox.x).toBeGreaterThanOrEqual(containerBox.x);
  expect.soft(elementBox.y).toBeGreaterThanOrEqual(containerBox.y);

  expect.soft(elementBox.x + elementBox.width).toBeLessThanOrEqual(containerBox.x + containerBox.width);
  expect.soft(elementBox.y + elementBox.height).toBeLessThanOrEqual(containerBox.y + containerBox.height);
}

test("TC-UX-004-01 - Verify Desktop Layout with Conversations Available and None Selected", async ({ page }) => {
  let primaryError: unknown;
  const cleanupErrors: unknown[] = [];
  //   const bobToAliceMessage = "Hi Alice. I'm good. How about you?";
  //   const charlieToAliceMessage = "Hi Alice. I'm good. How about you?";

  try {
    await deleteTestConversationBetweenUsers(alice.email, bob.email);
    await deleteTestConversationBetweenUsers(alice.email, charlie.email);

    await upsertRegisteredUser(alice);
    await upsertRegisteredUser(bob);
    await upsertRegisteredUser(charlie);

    const aliceBobConversationId = await createTestConversationBetweenUsers(alice.email, bob.email);
    const aliceCharlieConversationId = await createTestConversationBetweenUsers(alice.email, charlie.email);

    await createTestMessageInConversation(aliceBobConversationId, alice.email, bobMessage);
    // await createTestMessageInConversation(aliceBobConversationId, bob.email, bobToAliceMessage);

    await createTestMessageInConversation(aliceCharlieConversationId, alice.email, charlieMessage);
    // await createTestMessageInConversation(aliceCharlieConversationId, charlie.email, charlieToAliceMessage);

    await page.setViewportSize({
      width: 1366,
      height: 768,
    });

    await page.goto("/");

    await page.getByLabel("Email").fill(alice.email);
    await page.getByLabel("Password").fill(alice.password);

    await page.getByRole("button", { name: "Sign in" }).click();

    await expect(page).toHaveURL(/\/chat\/?$/);

    await expect(page.getByRole("heading", { name: "Conversations" })).toBeVisible();

    const currentUrl = new URL(page.url());

    expect(currentUrl.pathname).toBe("/chat");
    expect(currentUrl.searchParams.has("conversationId")).toBe(false);

    const appHeader = page.locator("main > header");

    const chatLayout = page.locator("main > div > section");
    const conversationListPanel = chatLayout.locator(":scope > aside");
    const mainChatArea = chatLayout.locator(":scope > section");

    await expect(conversationListPanel).toBeVisible();
    await expect(mainChatArea).toBeVisible();

    const listBox = await conversationListPanel.boundingBox();
    const chatBox = await mainChatArea.boundingBox();
    const layoutBox = await chatLayout.boundingBox();
    const headerBox = await appHeader.boundingBox();

    expect(listBox).not.toBeNull();
    expect(chatBox).not.toBeNull();
    expect(layoutBox).not.toBeNull();
    expect(headerBox).not.toBeNull();

    if (!listBox || !chatBox || !layoutBox || !headerBox) {
      throw new Error("Unable to measure the desktop layout.");
    }

    expect.soft(listBox.x + listBox.width).toBeLessThanOrEqual(chatBox.x);

    expect.soft(Math.abs(listBox.y - chatBox.y)).toBeLessThanOrEqual(1);
    expect.soft(Math.abs(listBox.height - chatBox.height)).toBeLessThanOrEqual(1);

    await expectWithinBounds(conversationListPanel, chatLayout);
    await expectWithinBounds(mainChatArea, chatLayout);

    expect.soft(headerBox.y + headerBox.height).toBeLessThanOrEqual(layoutBox.y);

    const bobConversation = conversationListPanel.getByRole("button").filter({ hasText: bob.name });

    const charlieConversation = conversationListPanel.getByRole("button").filter({ hasText: charlie.name });

    await expect.soft(bobConversation).toBeVisible();
    await expect.soft(charlieConversation).toBeVisible();

    await expect.soft(bobConversation).toContainText(bobMessage);
    await expect.soft(charlieConversation).toContainText(charlieMessage);

    await expect(bobConversation).toBeEnabled();
    await expect(charlieConversation).toBeEnabled();

    const emptyStateHeading = mainChatArea.getByRole("heading", {
      level: 2,
    });

    await expect.soft(emptyStateHeading).toHaveText("Select a conversation.");

    await expect.soft(mainChatArea.getByText("Choose a conversation from the list or start a new chat to begin messaging.", { exact: true })).toBeVisible();

    await expect.soft(mainChatArea.getByText(bobMessage, { exact: true })).toHaveCount(0);
    await expect.soft(mainChatArea.getByText(charlieMessage, { exact: true })).toHaveCount(0);

    await expect.soft(mainChatArea.getByLabel("Message")).toHaveCount(0);

    const emptyStateDescription = mainChatArea.getByText("Choose a conversation from the list or start a new chat to begin messaging.", { exact: true });

    for (const element of [emptyStateHeading, emptyStateDescription]) {
      const textFits = await element.evaluate((node) => {
        return node.scrollWidth <= node.clientWidth && node.scrollHeight <= node.clientHeight;
      });

      expect.soft(textFits).toBe(true);
    }

    const newChatHeading = conversationListPanel.getByRole("heading", {
      name: "New Chat",
    });

    const userSelect = conversationListPanel.getByRole("combobox");
    const startChatButton = conversationListPanel.getByRole("button", {
      name: "Start Chat",
    });

    await expect(newChatHeading).toBeVisible();
    await expect(userSelect).toBeVisible();
    await expect(startChatButton).toBeVisible();

    await expect(userSelect).toBeEnabled();
    await expect(startChatButton).toBeDisabled();

    await expectWithinBounds(bobConversation, conversationListPanel);
    await expectWithinBounds(charlieConversation, conversationListPanel);
    await expectWithinBounds(userSelect, conversationListPanel);
    await expectWithinBounds(startChatButton, conversationListPanel);

    await userSelect.selectOption({
      label: `${bob.name} (${bob.email})`,
    });

    await expect.soft(startChatButton).toBeEnabled();

    await userSelect.selectOption("");

    await expect.soft(startChatButton).toBeDisabled();

    const themeToggle = page.getByRole("button", {
      name: "Toggle theme",
    });

    const initialTheme = await page.locator("html").evaluate((element) => {
      return element.dataset.theme === "dark" ? "dark" : "light";
    });

    await expect(themeToggle).toBeVisible();
    await expect(themeToggle).toBeEnabled();

    await themeToggle.click();

    const changedTheme = await page.locator("html").evaluate((element) => {
      return element.dataset.theme === "dark" ? "dark" : "light";
    });

    expect.soft(changedTheme).not.toBe(initialTheme);

    await themeToggle.click();

    const restoredTheme = await page.locator("html").evaluate((element) => {
      return element.dataset.theme === "dark" ? "dark" : "light";
    });

    expect.soft(restoredTheme).toBe(initialTheme);

    const logoutButton = page.getByRole("button", {
      name: "Logout",
      exact: true,
    });

    await expect.soft(logoutButton).toBeVisible();
    await expect.soft(logoutButton).toBeEnabled();

    const viewport = {
      width: 1366,
      height: 768,
    };

    const importantElements = [themeToggle, logoutButton, userSelect, startChatButton, bobConversation, charlieConversation];

    for (const element of importantElements) {
      const box = await element.boundingBox();

      expect(box, "Important UI element should be measurable").not.toBeNull();

      if (!box) {
        throw new Error("Unable to measure an important UI element.");
      }

      expect.soft(box.x).toBeGreaterThanOrEqual(0);
      expect.soft(box.y).toBeGreaterThanOrEqual(0);
      expect.soft(box.x + box.width).toBeLessThanOrEqual(viewport.width);
      expect.soft(box.y + box.height).toBeLessThanOrEqual(viewport.height);
    }

    const horizontalOverflow = await page.evaluate(() => {
      return document.documentElement.scrollWidth > window.innerWidth || document.body.scrollWidth > window.innerWidth;
    });

    expect.soft(horizontalOverflow).toBe(false);
  } catch (error) {
    primaryError = error;
  } finally {
    let conversationCleanupSucceeded = false;

    try {
      await deleteTestConversationBetweenUsers(alice.email, bob.email);
      await deleteTestConversationBetweenUsers(alice.email, charlie.email);

      conversationCleanupSucceeded = true;
    } catch (error) {
      cleanupErrors.push(error);
    }

    if (conversationCleanupSucceeded) {
      const userCleanupResults = await Promise.allSettled([deleteTestUserByEmail(alice.email), deleteTestUserByEmail(bob.email), deleteTestUserByEmail(charlie.email)]);

      for (const result of userCleanupResults) {
        if (result.status === "rejected") {
          cleanupErrors.push(result.reason);
        }
      }
    }

    const disconnectResults = await Promise.allSettled([disconnectCleanupDatabase(), disconnectSetupDatabase()]);

    for (const result of disconnectResults) {
      if (result.status === "rejected") {
        cleanupErrors.push(result.reason);
      }
    }
  }

  if (primaryError && cleanupErrors.length > 0) {
    throw new AggregateError([primaryError, ...cleanupErrors], "Test execution and cleanup both encountered errors.");
  }

  if (primaryError) {
    throw primaryError;
  }

  if (cleanupErrors.length > 0) {
    throw new AggregateError(cleanupErrors, "Test cleanup encountered errors.");
  }
});
